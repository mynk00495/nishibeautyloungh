
import { Service, Offer, GalleryImage, Review, Booking } from '../types';

export const services: Service[] = [
  { id: 1, title: 'Classic Manicure', description: 'A timeless manicure for perfectly polished nails.', price: 800, duration: 45, category: 'Nails', image: 'https://picsum.photos/seed/manicure/400/300' },
  { id: 2, title: 'Gel Pedicure', description: 'Long-lasting gel polish for your toes.', price: 1200, duration: 60, category: 'Nails', image: 'https://picsum.photos/seed/pedicure/400/300' },
  { id: 3, title: 'Hydrating Facial', description: 'Deeply moisturizes and rejuvenates your skin.', price: 2500, duration: 75, category: 'Facial', image: 'https://picsum.photos/seed/facial/400/300' },
  { id: 4, title: 'Balayage Highlights', description: 'Natural-looking, sun-kissed hair color.', price: 5000, duration: 180, category: 'Hair', image: 'https://picsum.photos/seed/hair/400/300' },
  { id: 5, title: 'Bridal Makeup', description: 'Look your absolute best on your special day.', price: 8000, duration: 120, category: 'Makeup', image: 'https://picsum.photos/seed/makeup/400/300' },
  { id: 6, title: 'Swedish Massage', description: 'A relaxing full-body massage to ease tension.', price: 3000, duration: 60, category: 'Spa', image: 'https://picsum.photos/seed/spa/400/300' },
  { id: 7, title: 'Keratin Treatment', description: 'Smooth and straighten frizzy hair for a sleek look.', price: 6000, duration: 150, category: 'Hair', image: 'https://picsum.photos/seed/keratin/400/300' },
  { id: 8, title: 'Nail Art', description: 'Intricate and beautiful designs for your nails.', price: 1500, duration: 60, category: 'Nails', image: 'https://picsum.photos/seed/nailart/400/300' },
  { id: 9, title: 'Deep Tissue Massage', description: 'Targets deeper layers of muscle and connective tissue.', price: 3500, duration: 60, category: 'Spa', image: 'https://picsum.photos/seed/deeptissue/400/300' },
  { id: 10, title: 'Anti-Aging Facial', description: 'Combat signs of aging with this specialized treatment.', price: 3200, duration: 90, category: 'Facial', image: 'https://picsum.photos/seed/antiaging/400/300' },
];

export const offers: Offer[] = [
  { id: 1, title: 'Weekday Wonder', description: 'Get 20% off on all facials.', discount: 20, startDate: '2023-01-01', endDate: '2024-12-31', bannerImage: 'https://picsum.photos/seed/offer1/800/400', applicableServices: [3, 10] },
  { id: 2, title: 'Bridal Package Bonanza', description: 'Book bridal makeup and get a free classic manicure.', discount: 100, startDate: '2023-01-01', endDate: '2024-12-31', bannerImage: 'https://picsum.photos/seed/offer2/800/400', applicableServices: [5] },
  { id: 3, title: 'Hair & Nail Combo', description: '15% off when you book a hair treatment and a nail service together.', discount: 15, startDate: '2023-01-01', endDate: '2024-12-31', bannerImage: 'https://picsum.photos/seed/offer3/800/400', applicableServices: [1, 2, 4, 7, 8] },
];

export const galleryImages: GalleryImage[] = [
  { id: 1, title: 'Elegant Updo', url: 'https://picsum.photos/seed/gallery1/600/800', category: 'Hair' },
  { id: 2, title: 'Chrome Nails', url: 'https://picsum.photos/seed/gallery2/600/800', category: 'Nails' },
  { id: 3, title: 'Glowing Skin', url: 'https://picsum.photos/seed/gallery3/600/800', category: 'Facial' },
  { id: 4, title: 'Smokey Eye', url: 'https://picsum.photos/seed/gallery4/600/800', category: 'Makeup' },
  { id: 5, title: 'French Manicure', url: 'https://picsum.photos/seed/gallery5/600/800', category: 'Nails' },
  { id: 6, title: 'Blonde Balayage', url: 'https://picsum.photos/seed/gallery6/600/800', category: 'Hair' },
  { id: 7, title: 'Relaxing Spa Ambiance', url: 'https://picsum.photos/seed/gallery7/600/800', category: 'Spa' },
  { id: 8, title: 'Bold Red Lips', url: 'https://picsum.photos/seed/gallery8/600/800', category: 'Makeup' },
];

export const reviews: Review[] = [
  { id: 1, customerName: 'Priya S.', rating: 5, comment: 'Absolutely amazing experience! The staff is so professional and friendly. My facial was heavenly.', avatar: 'https://i.pravatar.cc/150?img=1' },
  { id: 2, customerName: 'Anjali M.', rating: 5, comment: 'I got my bridal makeup done here and it was flawless. Highly recommend Nishi Beauty Lounge!', avatar: 'https://i.pravatar.cc/150?img=2' },
  { id: 3, customerName: 'Rohan K.', rating: 4, comment: 'Great service and a very relaxing atmosphere. The massage was just what I needed.', avatar: 'https://i.pravatar.cc/150?img=3' },
  { id: 4, customerName: 'Sneha P.', rating: 5, comment: 'My nails have never looked better! The nail art is incredible and lasts so long.', avatar: 'https://i.pravatar.cc/150?img=4' }
];

export const bookings: Booking[] = [
  { id: 1, customerName: 'Priya S.', serviceId: 3, date: '2024-07-29', time: '11:30', status: 'Confirmed' },
  { id: 2, customerName: 'Anjali M.', serviceId: 5, date: '2024-07-29', time: '14:00', status: 'Confirmed' },
  { id: 3, customerName: 'Rohan K.', serviceId: 6, date: '2024-07-30', time: '10:00', status: 'Pending' },
  { id: 4, customerName: 'Sneha P.', serviceId: 8, date: '2024-07-30', time: '15:30', status: 'Confirmed' },
  { id: 5, customerName: 'Vikram B.', serviceId: 4, date: '2024-07-31', time: '12:15', status: 'Cancelled' },
  { id: 6, customerName: 'Meera C.', serviceId: 1, date: '2024-07-31', time: '16:15', status: 'Confirmed' },
];

// Mock API function to get available time slots
export const getAvailableSlots = (serviceId: number | null, date: Date | null): string[] => {
    if (!serviceId || !date) return [];
    // In a real app, this would be an API call. Here we generate mock slots.
    const day = date.getDay();
    if (day === 0) return []; // Closed on Sundays
    return ['10:00', '10:45', '11:30', '12:15', '14:00', '14:45', '15:30', '16:15', '17:00'];
};
