
import React from 'react';
import { Link } from 'react-router-dom';

const InstagramIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
        <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
    </svg>
);

const FacebookIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v7.028C18.343 21.128 22 16.991 22 12z" />
    </svg>
);

const WhatsAppIcon = ({ className = "w-6 h-6" }) => (
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.38 1.25 4.82l-1.34 4.92 5.04-1.32c1.4.74 2.97 1.18 4.63 1.18h.01c5.46 0 9.91-4.45 9.91-9.91s-4.45-9.91-9.92-9.91zm0 18.22h-.01c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.05-.2-.32c-.82-1.32-1.29-2.82-1.29-4.41 0-4.6 3.73-8.33 8.33-8.33 4.6 0 8.33 3.73 8.33 8.33.01 4.59-3.72 8.32-8.32 8.32zm4.53-6.13c-.27-.13-1.59-.78-1.84-.87-.25-.09-.43-.13-.62.13-.18.27-.69.87-.85 1.04-.15.18-.3.19-.55.06-.25-.13-1.06-.39-2.02-1.25-.75-.67-1.25-1.5-1.4-1.75-.15-.25-.02-.39.12-.51.12-.12.27-.3.4-.45.13-.15.18-.25.27-.42.09-.17.05-.31-.02-.43s-.62-1.49-.85-2.04c-.23-.55-.46-.48-.62-.48-.15 0-.33 0-.5 0-.18 0-.46.06-.7.33-.24.27-.92.9-1.12 2.19-.2 1.29.1 2.53.33 2.7.24.18 1.83 2.89 4.45 3.93.6.25 1.08.4 1.45.52.62.2 1.17.17 1.6.1.48-.09 1.59-.65 1.81-1.28.23-.63.23-1.17.15-1.28-.06-.11-.2-.18-.46-.31z"/>
     </svg>
);


const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* About Section */}
          <div className="md:col-span-1">
            <h3 className="text-xl font-bold font-serif mb-4">Nishi Beauty Lounge</h3>
            <p className="text-gray-400">
              Your sanctuary for beauty and wellness. We offer premium services to help you look and feel your best.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-400 hover:text-white">About Us</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white">Services</Link></li>
              <li><Link to="/gallery" className="text-gray-400 hover:text-white">Gallery</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <address className="not-italic space-y-2 text-gray-400">
              <p>123 Beauty Lane, Mumbai, India</p>
              <p>Email: <a href="mailto:contact@nishi.com" className="hover:text-white">contact@nishi.com</a></p>
              <p>Phone: <a href="tel:+911234567890" className="hover:text-white">+91 12345 67890</a></p>
            </address>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white"><InstagramIcon /></a>
              <a href="#" className="text-gray-400 hover:text-white"><FacebookIcon /></a>
              <a href="https://wa.me/911234567890" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white"><WhatsAppIcon /></a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-700 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Nishi Beauty Lounge. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
