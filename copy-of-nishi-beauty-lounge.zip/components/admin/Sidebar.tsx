
import React from 'react';
import { NavLink, useNavigate, Link } from 'react-router-dom';
import { LayoutDashboard, Calendar, Scissors, Tag, GalleryHorizontal, LogOut, Globe } from 'lucide-react';

const Sidebar = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        sessionStorage.removeItem('isAdminAuthenticated');
        navigate('/admin');
    };

    const navItems = [
        { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/panel/dashboard' },
        { icon: Calendar, label: 'Bookings', path: '/admin/panel/bookings' },
        { icon: Scissors, label: 'Services', path: '/admin/panel/services' },
        { icon: Tag, label: 'Offers', path: '/admin/panel/offers' },
        { icon: GalleryHorizontal, label: 'Gallery', path: '/admin/panel/gallery' },
    ];

    const activeLinkClass = 'bg-gray-700 text-white';
    const inactiveLinkClass = 'text-gray-300 hover:bg-gray-700 hover:text-white';

    return (
        <div className="w-64 bg-gray-800 text-white flex flex-col">
            <div className="h-20 flex items-center justify-center border-b border-gray-700">
                <Link to="/admin/panel/dashboard" className="text-xl font-bold font-serif">Admin Panel</Link>
            </div>
            <nav className="flex-1 px-2 py-4 space-y-2">
                {navItems.map(item => (
                    <NavLink
                        key={item.label}
                        to={item.path}
                        className={({ isActive }) =>
                            `flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${isActive ? activeLinkClass : inactiveLinkClass}`
                        }
                    >
                        <item.icon className="h-5 w-5 mr-3" />
                        {item.label}
                    </NavLink>
                ))}
                 <a href="/#/home" target="_blank" rel="noopener noreferrer" className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${inactiveLinkClass}`}>
                     <Globe className="h-5 w-5 mr-3" />
                     View Website
                </a>
            </nav>
            <div className="px-2 py-4 border-t border-gray-700">
                <button
                    onClick={handleLogout}
                    className={`w-full flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${inactiveLinkClass}`}
                >
                    <LogOut className="h-5 w-5 mr-3" />
                    Logout
                </button>
            </div>
        </div>
    );
};

export default Sidebar;
