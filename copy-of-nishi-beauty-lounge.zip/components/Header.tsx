
import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';

const MenuIcon = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M3 6.75A.75.75 0 013.75 6h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 6.75zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12zm0 5.25a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75a.75.75 0 01-.75-.75z" clipRule="evenodd" />
  </svg>
);

const CloseIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z" clipRule="evenodd" />
    </svg>
);


const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Home', path: '/home' },
    { name: 'Services', path: '/services' },
    { name: 'Offers', path: '/offers' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'About Us', path: '/about' },
    { name: 'Contact', path: '/contact' },
  ];
  
  const activeLinkStyle = {
    color: '#D4AF37', // A gold color
    textDecoration: 'underline',
    textUnderlineOffset: '4px'
  };

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <Link to="/home" className="text-2xl font-bold font-serif text-gray-800">
              Nishi Beauty Lounge
            </Link>
          </div>

          <nav className="hidden md:flex md:space-x-8">
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                style={({ isActive }) => isActive ? activeLinkStyle : {}}
                className="text-gray-600 hover:text-[#D4AF37] transition-colors duration-300"
              >
                {link.name}
              </NavLink>
            ))}
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <a href="tel:+911234567890" className="text-gray-600 hover:text-[#D4AF37]">
                +91 12345 67890
            </a>
            <Link
              to="/book"
              className="bg-[#C08497] text-white px-4 py-2 rounded-full hover:bg-[#A86F82] transition-colors duration-300 shadow"
            >
              Book Now
            </Link>
          </div>
          
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-800 focus:outline-none"
            >
              {isMenuOpen ? <CloseIcon /> : <MenuIcon />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute top-20 left-0 w-full">
          <nav className="flex flex-col items-center space-y-4 py-4">
            {navLinks.map((link) => (
              <NavLink
                key={link.name}
                to={link.path}
                onClick={() => setIsMenuOpen(false)}
                style={({ isActive }) => isActive ? activeLinkStyle : {}}
                className="text-gray-600 hover:text-[#D4AF37] py-2"
              >
                {link.name}
              </NavLink>
            ))}
            <a href="tel:+911234567890" className="text-gray-600 hover:text-[#D4AF37] py-2">
                +91 12345 67890
            </a>
            <Link
              to="/book"
              onClick={() => setIsMenuOpen(false)}
              className="bg-[#C08497] text-white px-6 py-3 rounded-full hover:bg-[#A86F82] transition-colors duration-300 shadow w-3/4 text-center"
            >
              Book Now
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
