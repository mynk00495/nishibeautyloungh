import React from 'react';

const PhoneIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M1.5 4.5a3 3 0 013-3h1.372c.86 0 1.61.586 1.819 1.42l1.105 4.423a1.875 1.875 0 01-.694 1.955l-1.293.97c-.135.101-.164.292-.086.431.794.87a11.17 11.17 0 004.283 4.283c.14.078.33.049.431-.086l.97-1.293a1.875 1.875 0 011.955-.694l4.423 1.105c.834.209 1.42.959 1.42 1.82V19.5a3 3 0 01-3 3h-2.25C8.552 22.5 1.5 15.448 1.5 6.75V4.5z" /></svg>
);
const MailIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M1.5 8.67v8.58a3 3 0 003 3h15a3 3 0 003-3V8.67l-8.928 5.493a3 3 0 01-3.144 0L1.5 8.67z" /><path d="M22.5 6.908V6.75a3 3 0 00-3-3h-15a3 3 0 00-3 3v.158l9.714 5.978a1.5 1.5 0 001.572 0L22.5 6.908z" /></svg>
);
const MapPinIcon = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}><path fillRule="evenodd" d="M11.54 22.351l.07.04.028.016a.76.76 0 00.723 0l.028-.015.071-.041a16.975 16.975 0 001.144-.742 19.58 19.58 0 002.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 00-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 002.682 2.282 16.975 16.975 0 001.145.742zM12 13.5a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" /></svg>
);

const ContactPage = () => {
    return (
        <div className="py-20">
            <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold font-serif">Get In Touch</h1>
                    <p className="text-gray-600 mt-4 max-w-2xl mx-auto">We'd love to hear from you. Reach out for appointments, inquiries, or just to say hello.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    {/* Contact Form */}
                    <div className="bg-white p-8 rounded-lg shadow-lg">
                        <h2 className="text-2xl font-bold font-serif mb-6">Send us a Message</h2>
                        <form>
                            <div className="mb-4">
                                <label htmlFor="name" className="block text-gray-700 font-medium mb-2">Name</label>
                                <input type="text" id="name" name="name" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C08497]" />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="email" className="block text-gray-700 font-medium mb-2">Email</label>
                                <input type="email" id="email" name="email" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C08497]" />
                            </div>
                            <div className="mb-4">
                                <label htmlFor="message" className="block text-gray-700 font-medium mb-2">Message</label>
                                <textarea id="message" name="message" rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C08497]"></textarea>
                            </div>
                            <button type="submit" className="w-full bg-[#C08497] text-white py-3 rounded-full font-semibold hover:bg-[#A86F82] transition-colors duration-300">
                                Send Message
                            </button>
                        </form>
                    </div>

                    {/* Contact Details & Map */}
                    <div className="space-y-8">
                        <div className="bg-white p-8 rounded-lg shadow-lg">
                            <h3 className="text-xl font-bold font-serif mb-4">Contact Information</h3>
                            <div className="space-y-4 text-gray-700">
                                <div className="flex items-center"><MapPinIcon className="w-6 h-6 mr-3 text-[#C08497]"/><p>123 Beauty Lane, Mumbai, India</p></div>
                                <div className="flex items-center"><MailIcon className="w-6 h-6 mr-3 text-[#C08497]"/><a href="mailto:contact@nishi.com" className="hover:underline">contact@nishi.com</a></div>
                                <div className="flex items-center"><PhoneIcon className="w-6 h-6 mr-3 text-[#C08497]"/><a href="tel:+911234567890" className="hover:underline">+91 12345 67890</a></div>
                            </div>
                            <div className="mt-6 pt-6 border-t">
                                <h3 className="text-xl font-bold font-serif mb-4">Business Hours</h3>
                                <ul className="space-y-1 text-gray-700">
                                    <li>Monday - Friday: 9:00 AM - 7:00 PM</li>
                                    <li>Saturday: 10:00 AM - 6:00 PM</li>
                                    <li>Sunday: Closed</li>
                                </ul>
                            </div>
                        </div>
                        <div className="h-64 rounded-lg shadow-lg overflow-hidden">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3770.710776510427!2d72.88560961539414!3d19.07639538708752!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c8ab3b10b37f%3A0x8c3b516b8b0b1e1b!2sBandra%20Kurla%20Complex%2C%20Bandra%20East%2C%20Mumbai%2C%20Maharashtra%20400051!5e0!3m2!1sen!2sin!4v1678886475713!5m2!1sen!2sin"
                                width="100%"
                                height="100%"
                                style={{ border: 0 }}
                                allowFullScreen={true}
                                loading="lazy"
                                // FIX: Corrected typo in referrerPolicy to match valid HTML attribute values.
                                referrerPolicy="no-referrer-when-downgrade"
                            ></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactPage;