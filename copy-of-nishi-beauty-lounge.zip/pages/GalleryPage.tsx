
import React, { useState } from 'react';
import { galleryImages } from '../data/mockData';

const GalleryPage = () => {
    const categories = ['All', ...Array.from(new Set(galleryImages.map(img => img.category)))];
    const [activeCategory, setActiveCategory] = useState('All');
    const [selectedImg, setSelectedImg] = useState<string | null>(null);

    const filteredImages = activeCategory === 'All'
        ? galleryImages
        : galleryImages.filter(img => img.category === activeCategory);

    return (
        <div className="py-20">
            <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold font-serif">Our Gallery</h1>
                    <p className="text-gray-600 mt-4 max-w-2xl mx-auto">A glimpse into the artistry and transformations at Nishi Beauty Lounge.</p>
                </div>

                <div className="flex justify-center flex-wrap gap-2 md:gap-4 mb-12">
                    {categories.map(category => (
                        <button
                            key={category}
                            onClick={() => setActiveCategory(category)}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-300 ${
                                activeCategory === category
                                    ? 'bg-gray-800 text-white'
                                    : 'bg-white text-gray-700 hover:bg-gray-200'
                            }`}
                        >
                            {category}
                        </button>
                    ))}
                </div>
                
                <div className="columns-2 md:columns-3 lg:columns-4 gap-4">
                    {filteredImages.map(image => (
                        <div key={image.id} className="mb-4 break-inside-avoid cursor-pointer" onClick={() => setSelectedImg(image.url)}>
                            <img src={image.url} alt={image.title} className="w-full rounded-lg shadow-md hover:opacity-80 transition-opacity" />
                        </div>
                    ))}
                </div>
            </div>
            
            {selectedImg && (
                <div 
                    className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50"
                    onClick={() => setSelectedImg(null)}
                >
                    <img src={selectedImg} alt="Enlarged view" className="max-w-[90vw] max-h-[90vh] rounded-lg shadow-2xl" />
                </div>
            )}
        </div>
    );
};

export default GalleryPage;
