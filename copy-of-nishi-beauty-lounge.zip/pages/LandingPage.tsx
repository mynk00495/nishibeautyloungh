
import React from 'react';
import { Link } from 'react-router-dom';
import { User, ShieldCheck, ArrowRight } from 'lucide-react';

const LandingPage = () => {
    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4" style={{
            background: 'linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url(https://picsum.photos/seed/salonbg/1920/1080)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
        }}>
            <div className="text-center mb-12">
                <h1 className="text-5xl md:text-7xl font-bold font-serif text-[#D4AF37]">Nishi Beauty Lounge</h1>
                <p className="text-lg text-gray-300 mt-2 italic">"Where Beauty Meets Elegance"</p>
            </div>

            <div className="w-full max-w-sm space-y-6">
                <h2 className="text-2xl text-center text-gray-200">Welcome! How would you like to proceed?</h2>
                <Link to="/home" className="group flex items-center justify-between w-full bg-yellow-500/10 border border-yellow-500 text-yellow-400 px-6 py-4 rounded-lg hover:bg-yellow-500/20 transition-all duration-300">
                    <div className="flex items-center">
                        <User className="w-6 h-6 mr-4"/>
                        <div>
                            <span className="font-bold text-lg">I'm a Customer</span>
                            <p className="text-sm text-yellow-500/80">Book appointment & explore</p>
                        </div>
                    </div>
                    <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all duration-300"/>
                </Link>

                <Link to="/admin" className="group flex items-center justify-between w-full bg-gray-500/10 border border-gray-500 text-gray-300 px-6 py-4 rounded-lg hover:bg-gray-500/20 transition-all duration-300">
                    <div className="flex items-center">
                        <ShieldCheck className="w-6 h-6 mr-4"/>
                        <div>
                            <span className="font-bold text-lg">I'm the Owner</span>
                            <p className="text-sm text-gray-400">Access admin dashboard</p>
                        </div>
                    </div>
                     <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transform -translate-x-2 group-hover:translate-x-0 transition-all duration-300"/>
                </Link>
            </div>
             <div className="absolute bottom-4 text-center text-gray-500 text-sm">
                 <p>&copy; {new Date().getFullYear()} Nishi Beauty Lounge. All Rights Reserved.</p>
            </div>
        </div>
    );
};

export default LandingPage;
