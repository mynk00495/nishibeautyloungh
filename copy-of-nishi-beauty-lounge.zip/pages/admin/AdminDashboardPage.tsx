
import React from 'react';
import { bookings, services } from '../../data/mockData';
import { Booking } from '../../types';
import { Calendar, Users, Clock, IndianRupee, CheckCircle, AlertCircle, XCircle } from 'lucide-react';

const StatCard = ({ title, value, icon, color }: { title: string, value: string | number, icon: React.ElementType, color: string }) => {
    const Icon = icon;
    return (
        <div className={`p-6 rounded-lg shadow-md text-white ${color}`}>
            <div className="flex items-center">
                <div className="p-3 bg-white/20 rounded-full mr-4">
                    <Icon className="h-6 w-6" />
                </div>
                <div>
                    <p className="text-sm font-medium">{title}</p>
                    <p className="text-2xl font-bold">{value}</p>
                </div>
            </div>
        </div>
    );
};

const BookingStatusBadge = ({ status }: { status: Booking['status'] }) => {
    const baseClasses = "px-2 py-1 text-xs font-medium rounded-full inline-flex items-center";
    switch(status) {
        case 'Confirmed': return <span className={`${baseClasses} bg-green-100 text-green-800`}><CheckCircle size={12} className="mr-1"/>Confirmed</span>;
        case 'Pending': return <span className={`${baseClasses} bg-yellow-100 text-yellow-800`}><AlertCircle size={12} className="mr-1"/>Pending</span>;
        case 'Cancelled': return <span className={`${baseClasses} bg-red-100 text-red-800`}><XCircle size={12} className="mr-1"/>Cancelled</span>;
        default: return <span className={`${baseClasses} bg-gray-100 text-gray-800`}>Unknown</span>;
    }
};

const AdminDashboardPage = () => {
    const today = new Date().toISOString().split('T')[0];
    const todaysBookings = bookings.filter(b => b.date === today && b.status === 'Confirmed').length;
    const totalRevenue = bookings
        .filter(b => b.status === 'Confirmed')
        .reduce((sum, booking) => {
            const service = services.find(s => s.id === booking.serviceId);
            return sum + (service ? service.price : 0);
        }, 0);
    const pendingBookings = bookings.filter(b => b.status === 'Pending').length;

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-6">Welcome back, Owner!</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard title="Today's Bookings" value={todaysBookings} icon={Calendar} color="bg-gradient-to-r from-blue-500 to-blue-400" />
                <StatCard title="Total Revenue" value={`₹${totalRevenue.toLocaleString()}`} icon={IndianRupee} color="bg-gradient-to-r from-green-500 to-green-400" />
                <StatCard title="Pending Appointments" value={pendingBookings} icon={Clock} color="bg-gradient-to-r from-yellow-500 to-yellow-400" />
                <StatCard title="Total Customers" value={bookings.length} icon={Users} color="bg-gradient-to-r from-purple-500 to-purple-400" />
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-bold text-gray-700 mb-4">Recent Bookings</h2>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-gray-50">
                                <th className="p-3 text-sm font-semibold text-gray-600">Customer</th>
                                <th className="p-3 text-sm font-semibold text-gray-600">Service</th>
                                <th className="p-3 text-sm font-semibold text-gray-600">Date & Time</th>
                                <th className="p-3 text-sm font-semibold text-gray-600">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bookings.slice(0, 5).map(booking => {
                                const service = services.find(s => s.id === booking.serviceId);
                                return (
                                    <tr key={booking.id} className="border-b hover:bg-gray-50">
                                        <td className="p-3">{booking.customerName}</td>
                                        <td className="p-3 text-sm text-gray-600">{service ? service.title : 'Unknown Service'}</td>
                                        <td className="p-3 text-sm">{new Date(booking.date).toLocaleDateString()} at {booking.time}</td>
                                        <td className="p-3"><BookingStatusBadge status={booking.status} /></td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboardPage;
