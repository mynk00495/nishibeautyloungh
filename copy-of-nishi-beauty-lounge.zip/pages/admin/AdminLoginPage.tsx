
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Lock, Eye, EyeOff } from 'lucide-react';

const AdminLoginPage = () => {
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();
    
    // In a real app, this should be a secure backend authentication process
    const correctPassword = 'admin123';

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (password === correctPassword) {
            setError('');
            sessionStorage.setItem('isAdminAuthenticated', 'true');
            navigate('/admin/panel/dashboard');
        } else {
            setError('Incorrect password. Please try again.');
        }
    };

    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col items-center justify-center p-4" style={{
            background: 'linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0.8)), url(https://picsum.photos/seed/adminbg/1920/1080)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
        }}>
            <div className="text-center mb-8">
                <h1 className="text-3xl font-bold font-serif text-[#D4AF37]">Nishi Beauty Lounge</h1>
                <p className="text-lg text-gray-300 mt-1">Owner Panel</p>
            </div>

            <div className="w-full max-w-sm bg-black/30 backdrop-blur-sm p-8 rounded-lg border border-gray-700">
                <form onSubmit={handleLogin}>
                    <div className="text-center mb-6">
                        <Lock className="w-8 h-8 mx-auto text-gray-400 mb-2"/>
                        <h2 className="text-xl font-bold">Owner Access</h2>
                        <p className="text-sm text-gray-400">Enter your password to continue</p>
                    </div>
                    
                    <div className="relative mb-4">
                        <input
                            type={showPassword ? 'text' : 'password'}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="Enter password"
                            className="w-full bg-gray-800/50 border border-gray-600 rounded-md px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500"
                        />
                        <button 
                          type="button" 
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                        >
                          {showPassword ? <EyeOff size={20}/> : <Eye size={20} />}
                        </button>
                    </div>
                    
                    {error && <p className="text-red-500 text-sm mb-4 text-center">{error}</p>}

                    <button
                        type="submit"
                        className="w-full bg-yellow-500 text-gray-900 font-bold py-3 rounded-md hover:bg-yellow-400 transition-colors"
                    >
                        Access Dashboard
                    </button>
                </form>
                 <div className="text-center mt-6">
                    <Link to="/" className="text-sm text-gray-400 hover:text-white hover:underline">&larr; Back to Home</Link>
                </div>
            </div>
             <div className="absolute bottom-4 text-center text-gray-500 text-xs">
                 <p>This area is restricted to authorized personnel only.</p>
            </div>
        </div>
    );
};

export default AdminLoginPage;
