
import React from 'react';
import { Link } from 'react-router-dom';
import { services, offers, reviews, galleryImages } from '../data/mockData';
import { Star } from 'lucide-react';

const HeroSlider = () => {
    // Basic static hero section for now. A real slider would need a library or more complex state.
    return (
        <div className="relative bg-cover bg-center h-[60vh] md:h-[80vh]" style={{ backgroundImage: `url('https://picsum.photos/seed/hero/1600/900')` }}>
            <div className="absolute inset-0 bg-black bg-opacity-40"></div>
            <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-center text-center text-white">
                <h1 className="text-4xl md:text-6xl font-bold font-serif mb-4 leading-tight">Experience True Beauty & Relaxation</h1>
                <p className="text-lg md:text-xl mb-8 max-w-2xl">Indulge in our world-class services and let our experts pamper you.</p>
                <Link to="/book" className="bg-[#D4AF37] text-gray-900 px-8 py-4 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-transform transform hover:scale-105 shadow-lg">
                    Book an Appointment
                </Link>
            </div>
        </div>
    );
};

// FIX: Changed to React.FC to correctly handle props like 'key'.
const ServiceCard: React.FC<{ service: typeof services[0] }> = ({ service }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden group transform hover:-translate-y-2 transition-transform duration-300">
        <img src={service.image} alt={service.title} className="w-full h-48 object-cover" />
        <div className="p-4">
            <h3 className="text-xl font-bold font-serif">{service.title}</h3>
            <p className="text-gray-600 mt-2 text-sm">{service.description}</p>
            <div className="flex justify-between items-center mt-4">
                <span className="font-bold text-lg text-[#C08497]">₹{service.price}</span>
                <Link to="/book" state={{ serviceId: service.id }} className="text-[#C08497] font-semibold hover:underline">Book Now</Link>
            </div>
        </div>
    </div>
);

// FIX: Changed to React.FC to correctly handle props like 'key'.
const ReviewCard: React.FC<{ review: typeof reviews[0] }> = ({ review }) => (
    <div className="bg-white p-6 rounded-lg shadow-lg mx-2 flex-shrink-0 w-80">
        <div className="flex items-center mb-4">
            <img src={review.avatar} alt={review.customerName} className="w-12 h-12 rounded-full mr-4" />
            <div>
                <h4 className="font-bold">{review.customerName}</h4>
                <div className="flex text-yellow-500">
                    {[...Array(review.rating)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
                    {[...Array(5-review.rating)].map((_, i) => <Star key={i} size={16} />)}
                </div>
            </div>
        </div>
        <p className="text-gray-600 italic">"{review.comment}"</p>
    </div>
);

const HomePage = () => {
    const featuredServices = services.slice(0, 4);
    const featuredGallery = galleryImages.slice(0, 4);

    return (
        <div>
            <HeroSlider />

            <section className="py-20 bg-white">
                <div className="container mx-auto px-4 text-center">
                    <h2 className="text-3xl md:text-4xl font-bold font-serif mb-4">Welcome to Nishi Beauty Lounge</h2>
                    <p className="max-w-3xl mx-auto text-gray-600">
                        At Nishi Beauty Lounge, we believe in the art of beautification and the science of relaxation. Our expert team is dedicated to providing you with an unparalleled experience, using only the finest products and the latest techniques. Step into our serene world and emerge refreshed, rejuvenated, and radiant.
                    </p>
                </div>
            </section>
            
            <section className="py-20">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl md:text-4xl font-bold font-serif text-center mb-12">Our Popular Services</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                        {featuredServices.map(service => <ServiceCard key={service.id} service={service} />)}
                    </div>
                    <div className="text-center mt-12">
                        <Link to="/services" className="bg-[#C08497] text-white px-8 py-3 rounded-full text-lg hover:bg-[#A86F82] transition-colors duration-300 shadow">
                            View All Services
                        </Link>
                    </div>
                </div>
            </section>

             <section className="py-20 bg-white">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl md:text-4xl font-bold font-serif text-center mb-12">Special Offers</h2>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {offers.slice(0,3).map(offer => (
                            <div key={offer.id} className="relative rounded-lg overflow-hidden shadow-lg group">
                                <img src={offer.bannerImage} alt={offer.title} className="w-full h-64 object-cover"/>
                                <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col justify-end p-6">
                                    <h3 className="text-2xl font-bold font-serif text-white">{offer.title}</h3>
                                    <p className="text-gray-200 mt-2">{offer.description}</p>
                                    <Link to="/offers" className="text-white font-bold mt-4 self-start border-b-2 border-transparent group-hover:border-white transition-all">
                                        Learn More &rarr;
                                    </Link>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            <section className="py-20">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl md:text-4xl font-bold font-serif text-center mb-12">What Our Clients Say</h2>
                    <div className="flex overflow-x-auto pb-4 -mx-4 px-4">
                        {reviews.map(review => <ReviewCard key={review.id} review={review} />)}
                    </div>
                </div>
            </section>
            
            <section className="py-20 bg-white">
                <div className="container mx-auto px-4">
                    <h2 className="text-3xl md:text-4xl font-bold font-serif text-center mb-12">Our Gallery</h2>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {featuredGallery.map(img => (
                            <div key={img.id} className="overflow-hidden rounded-lg shadow-md">
                                <img src={img.url} alt={img.title} className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-300" />
                            </div>
                        ))}
                    </div>
                    <div className="text-center mt-12">
                        <Link to="/gallery" className="bg-gray-800 text-white px-8 py-3 rounded-full text-lg hover:bg-gray-700 transition-colors duration-300 shadow">
                            View Full Gallery
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default HomePage;