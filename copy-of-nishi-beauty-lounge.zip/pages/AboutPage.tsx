
import React from 'react';

const AboutPage = () => {
  return (
    <div className="bg-white">
      <div className="relative h-80 bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/seed/aboutus/1200/400')" }}>
        <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <h1 className="text-5xl font-bold font-serif text-white">About Us</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold font-serif text-gray-800 mb-4">Our Story</h2>
            <p className="text-gray-600 mb-4">
              Nishi Beauty Lounge was founded with a simple vision: to create a sanctuary where beauty, comfort, and personalized attention combine to create a memorable and rejuvenating experience. Our journey began over a decade ago, fueled by a passion for aesthetics and a commitment to excellence.
            </p>
            <p className="text-gray-600">
              We have grown into a premier destination for those seeking the finest in hair, skin, and nail care. Our team of skilled professionals is dedicated to staying at the forefront of the industry, continuously learning and mastering the latest techniques and trends to provide you with the best possible service.
            </p>
          </div>
          <div>
            <img src="https://picsum.photos/seed/team/600/400" alt="Salon Interior" className="rounded-lg shadow-xl" />
          </div>
        </div>

        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold font-serif text-gray-800 mb-4">Our Mission</h2>
          <p className="max-w-3xl mx-auto text-gray-600">
            To enhance the natural beauty of our clients by providing high-quality, personalized beauty services in a welcoming and luxurious environment. We strive to exceed expectations, ensuring every visit is a relaxing and uplifting experience that leaves you feeling confident and radiant.
          </p>
        </div>

        <div className="mt-20">
           <h2 className="text-3xl font-bold font-serif text-gray-800 mb-12 text-center">Meet Our Experts</h2>
           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
               <div className="text-center">
                   <img src="https://i.pravatar.cc/150?img=5" alt="Nishi Sharma" className="w-32 h-32 rounded-full mx-auto mb-4 shadow-md" />
                   <h3 className="font-bold text-xl">Nishi Sharma</h3>
                   <p className="text-gray-500">Founder & Lead Stylist</p>
               </div>
               <div className="text-center">
                   <img src="https://i.pravatar.cc/150?img=6" alt="Riya Gupta" className="w-32 h-32 rounded-full mx-auto mb-4 shadow-md" />
                   <h3 className="font-bold text-xl">Riya Gupta</h3>
                   <p className="text-gray-500">Senior Esthetician</p>
               </div>
               <div className="text-center">
                   <img src="https://i.pravatar.cc/150?img=7" alt="Amit Patel" className="w-32 h-32 rounded-full mx-auto mb-4 shadow-md" />
                   <h3 className="font-bold text-xl">Amit Patel</h3>
                   <p className="text-gray-500">Master Nail Artist</p>
               </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
