
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { offers } from '../data/mockData';
import { Offer } from '../types';

const CountdownTimer = ({ endDate }: { endDate: string }) => {
    const calculateTimeLeft = () => {
        const difference = +new Date(endDate) - +new Date();
        // FIX: Explicitly type timeLeft to prevent `value` from being `unknown`.
        let timeLeft: { [key: string]: number } = {};

        if (difference > 0) {
            timeLeft = {
                days: Math.floor(difference / (1000 * 60 * 60 * 24)),
                hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
                minutes: Math.floor((difference / 1000 / 60) % 60),
            };
        }

        return timeLeft;
    };

    const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

    useEffect(() => {
        const timer = setTimeout(() => {
            setTimeLeft(calculateTimeLeft());
        }, 1000);

        return () => clearTimeout(timer);
    });

    const timerComponents = Object.entries(timeLeft).map(([interval, value]) => {
        if(value <= 0 && interval !== 'days') return null;
        return (
            <div key={interval} className="text-center">
                <span className="text-2xl font-bold">{String(value).padStart(2, '0')}</span>
                <span className="text-xs uppercase block">{interval}</span>
            </div>
        );
    }).filter(Boolean);

    return timerComponents.length ? (
        <div className="flex space-x-4 text-white">
            {timerComponents.map((component, index) => <React.Fragment key={index}>{component}</React.Fragment>)}
        </div>
    ) : <span className="text-red-400 font-bold">Offer Expired!</span>;
};

// FIX: Changed to React.FC to correctly handle props like 'key'.
const OfferCard: React.FC<{ offer: Offer }> = ({ offer }) => {
    return (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col md:flex-row">
            <img src={offer.bannerImage} alt={offer.title} className="w-full md:w-1/2 h-64 md:h-auto object-cover" />
            <div className="p-6 flex flex-col justify-between w-full">
                <div>
                    <span className="inline-block bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full uppercase mb-2">
                        {offer.discount}% OFF
                    </span>
                    <h3 className="text-2xl font-bold font-serif mb-2">{offer.title}</h3>
                    <p className="text-gray-600 mb-4">{offer.description}</p>
                </div>
                <div>
                    <div className="bg-gray-800 p-4 rounded-lg mb-4">
                       <CountdownTimer endDate={offer.endDate} />
                    </div>
                    <Link to="/services" className="bg-[#C08497] text-white w-full text-center block py-3 rounded-full font-semibold hover:bg-[#A86F82] transition-colors duration-300">
                        Book Now & Avail Offer
                    </Link>
                </div>
            </div>
        </div>
    );
}

const OffersPage = () => {
    return (
        <div className="py-20">
            <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold font-serif">Special Offers</h1>
                    <p className="text-gray-600 mt-4 max-w-2xl mx-auto">Don't miss out on our exclusive deals. Pamper yourself for less!</p>
                </div>

                <div className="space-y-8">
                    {offers.map(offer => (
                        <OfferCard key={offer.id} offer={offer} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default OffersPage;