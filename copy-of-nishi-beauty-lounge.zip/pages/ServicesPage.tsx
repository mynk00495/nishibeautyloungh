
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { services } from '../data/mockData';
import { Service } from '../types';

// FIX: Changed to React.FC to correctly handle props like 'key'.
const ServiceCard: React.FC<{ service: Service }> = ({ service }) => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden group transform hover:-translate-y-2 transition-transform duration-300 flex flex-col">
        <img src={service.image} alt={service.title} className="w-full h-56 object-cover" />
        <div className="p-6 flex flex-col flex-grow">
            <h3 className="text-xl font-bold font-serif mb-2">{service.title}</h3>
            <p className="text-gray-600 text-sm mb-4 flex-grow">{service.description}</p>
            <div className="flex justify-between items-center mt-auto">
                <div>
                    <span className="font-bold text-lg text-[#C08497]">₹{service.price}</span>
                    <span className="text-gray-500 text-sm ml-2">({service.duration} min)</span>
                </div>
                <Link 
                    to="/book" 
                    state={{ serviceId: service.id }}
                    className="bg-[#C08497] text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-[#A86F82] transition-colors duration-300"
                >
                    Book Now
                </Link>
            </div>
        </div>
    </div>
);


const ServicesPage = () => {
    const categories = ['All', ...Array.from(new Set(services.map(s => s.category)))];
    const [activeCategory, setActiveCategory] = useState('All');

    const filteredServices = activeCategory === 'All'
        ? services
        : services.filter(service => service.category === activeCategory);

    return (
        <div className="py-20">
            <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold font-serif">Our Services</h1>
                    <p className="text-gray-600 mt-4 max-w-2xl mx-auto">Discover our range of premium services, designed to make you look and feel extraordinary.</p>
                </div>
                
                <div className="flex justify-center flex-wrap gap-2 md:gap-4 mb-12">
                    {categories.map(category => (
                        <button
                            key={category}
                            onClick={() => setActiveCategory(category)}
                            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors duration-300 ${
                                activeCategory === category
                                    ? 'bg-gray-800 text-white'
                                    : 'bg-white text-gray-700 hover:bg-gray-200'
                            }`}
                        >
                            {category}
                        </button>
                    ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredServices.map(service => (
                        <ServiceCard key={service.id} service={service} />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ServicesPage;