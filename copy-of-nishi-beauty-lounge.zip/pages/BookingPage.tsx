
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { services, getAvailableSlots } from '../data/mockData';
import { BookingData, Service } from '../types';

enum BookingStep {
    SERVICE,
    DATETIME,
    DETAILS,
    CONFIRMATION
}

const BookingPage = () => {
    const location = useLocation();
    const [step, setStep] = useState<BookingStep>(BookingStep.SERVICE);
    const [bookingData, setBookingData] = useState<BookingData>({
        serviceId: null,
        date: null,
        time: null,
        customerName: '',
        customerPhone: '',
        customerEmail: '',
        notes: '',
    });
    const [availableSlots, setAvailableSlots] = useState<string[]>([]);
    
    useEffect(() => {
        if (location.state?.serviceId) {
            setBookingData(prev => ({ ...prev, serviceId: location.state.serviceId }));
            setStep(BookingStep.DATETIME);
        }
    }, [location.state]);

    useEffect(() => {
        if (bookingData.date && bookingData.serviceId) {
            const slots = getAvailableSlots(bookingData.serviceId, bookingData.date);
            setAvailableSlots(slots);
        } else {
            setAvailableSlots([]);
        }
    }, [bookingData.date, bookingData.serviceId]);
    
    const handleServiceSelect = (serviceId: number) => {
        setBookingData({ ...bookingData, serviceId, date: null, time: null });
        setStep(BookingStep.DATETIME);
    };
    
    const handleDateSelect = (date: Date) => {
        setBookingData({ ...bookingData, date, time: null });
    };

    const handleTimeSelect = (time: string) => {
        setBookingData({ ...bookingData, time });
        setStep(BookingStep.DETAILS);
    };

    const handleDetailsSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setStep(BookingStep.CONFIRMATION);
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setBookingData(prev => ({ ...prev, [name]: value }));
    };

    const resetBooking = () => {
        setBookingData({
            serviceId: null, date: null, time: null,
            customerName: '', customerPhone: '', customerEmail: '', notes: '',
        });
        setStep(BookingStep.SERVICE);
    };

    const selectedService = services.find(s => s.id === bookingData.serviceId);

    const renderStep = () => {
        switch (step) {
            case BookingStep.SERVICE:
                return (
                    <div>
                        <h2 className="text-2xl font-bold font-serif mb-6 text-center">Step 1: Choose a Service</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {services.map(service => (
                                <button key={service.id} onClick={() => handleServiceSelect(service.id)} className="p-4 border rounded-lg text-left hover:bg-gray-100 transition">
                                    <h3 className="font-bold">{service.title}</h3>
                                    <p className="text-sm text-gray-600">{service.duration} min - ₹{service.price}</p>
                                </button>
                            ))}
                        </div>
                    </div>
                );
            case BookingStep.DATETIME:
                return (
                    <div>
                        <h2 className="text-2xl font-bold font-serif mb-2 text-center">Step 2: Choose Date & Time</h2>
                        <p className="text-center text-gray-600 mb-6">For: {selectedService?.title}</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                                <h3 className="font-semibold mb-2">Select Date</h3>
                                <input 
                                    type="date" 
                                    min={new Date().toISOString().split('T')[0]}
                                    className="w-full p-2 border rounded-lg"
                                    onChange={(e) => handleDateSelect(new Date(e.target.value))}
                                />
                            </div>
                            <div>
                                <h3 className="font-semibold mb-2">Available Times</h3>
                                {bookingData.date ? (
                                    <div className="grid grid-cols-3 gap-2">
                                        {availableSlots.length > 0 ? availableSlots.map(slot => (
                                            <button key={slot} onClick={() => handleTimeSelect(slot)} className="p-2 border rounded-lg hover:bg-[#C08497] hover:text-white transition">
                                                {slot}
                                            </button>
                                        )) : <p className="text-gray-500 col-span-3">No slots available. Please select another date.</p>}
                                    </div>
                                ) : <p className="text-gray-500">Please select a date first.</p>}
                            </div>
                        </div>
                         <button onClick={() => setStep(BookingStep.SERVICE)} className="mt-8 text-sm text-gray-600 hover:underline">Back to Services</button>
                    </div>
                );
            case BookingStep.DETAILS:
                return (
                     <div>
                        <h2 className="text-2xl font-bold font-serif mb-6 text-center">Step 3: Your Details</h2>
                        <form onSubmit={handleDetailsSubmit}>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                <input name="customerName" placeholder="Full Name" required className="p-2 border rounded-lg w-full" onChange={handleInputChange} value={bookingData.customerName} />
                                <input name="customerPhone" placeholder="Phone Number" required className="p-2 border rounded-lg w-full" onChange={handleInputChange} value={bookingData.customerPhone} />
                            </div>
                            <input name="customerEmail" type="email" placeholder="Email Address" required className="p-2 border rounded-lg w-full mb-4" onChange={handleInputChange} value={bookingData.customerEmail} />
                            <textarea name="notes" placeholder="Additional Notes (optional)" className="p-2 border rounded-lg w-full mb-4" rows={3} onChange={handleInputChange} value={bookingData.notes}></textarea>
                            <button type="submit" className="w-full bg-[#C08497] text-white py-3 rounded-full font-semibold hover:bg-[#A86F82] transition">Continue to Confirmation</button>
                        </form>
                         <button onClick={() => setStep(BookingStep.DATETIME)} className="mt-4 text-sm text-gray-600 hover:underline">Back to Date/Time</button>
                    </div>
                );
            case BookingStep.CONFIRMATION:
                return (
                     <div className="text-center">
                        <h2 className="text-3xl font-bold font-serif mb-4">Booking Confirmed!</h2>
                        <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                        <p className="text-gray-700 mb-6">Thank you, {bookingData.customerName}. Your appointment is booked.</p>
                        <div className="bg-gray-100 p-6 rounded-lg text-left mb-6">
                            <h3 className="font-bold text-lg mb-4">Appointment Details:</h3>
                            <p><strong>Service:</strong> {selectedService?.title}</p>
                            <p><strong>Date:</strong> {bookingData.date?.toLocaleDateString()}</p>
                            <p><strong>Time:</strong> {bookingData.time}</p>
                            <p><strong>Email:</strong> {bookingData.customerEmail}</p>
                        </div>
                        <p className="text-sm text-gray-500">A confirmation has been sent to your email. We look forward to seeing you!</p>
                        <button onClick={resetBooking} className="mt-8 bg-gray-800 text-white py-2 px-6 rounded-full hover:bg-gray-700 transition">Book Another Appointment</button>
                    </div>
                );
        }
    }

    return (
        <div className="py-20">
            <div className="container mx-auto px-4">
                <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-2xl">
                    {renderStep()}
                </div>
            </div>
        </div>
    );
};

export default BookingPage;
