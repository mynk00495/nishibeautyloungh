
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import CustomerLayout from './components/CustomerLayout';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import OffersPage from './pages/OffersPage';
import GalleryPage from './pages/GalleryPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import BookingPage from './pages/BookingPage';
import LandingPage from './pages/LandingPage';
import AdminLoginPage from './pages/admin/AdminLoginPage';
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import PrivateRoute from './components/PrivateRoute';
import AdminLayout from './components/admin/AdminLayout';

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        
        {/* Customer Facing Site */}
        <Route element={<CustomerLayout />}>
          <Route path="/home" element={<HomePage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/offers" element={<OffersPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/book" element={<BookingPage />} />
        </Route>

        {/* Admin Portal */}
        <Route path="/admin" element={<AdminLoginPage />} />
        <Route element={<PrivateRoute />}>
            <Route path="/admin/panel" element={<AdminLayout />}>
                <Route index element={<Navigate to="dashboard" />} />
                <Route path="dashboard" element={<AdminDashboardPage />} />
                {/* Future admin routes can be added here */}
            </Route>
        </Route>

      </Routes>
    </HashRouter>
  );
}

export default App;
