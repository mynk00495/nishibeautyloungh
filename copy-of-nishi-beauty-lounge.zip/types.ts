
export interface Service {
  id: number;
  title: string;
  description: string;
  price: number;
  duration: number; // in minutes
  category: string;
  image: string;
}

export interface Offer {
  id: number;
  title:string;
  description:string;
  discount: number; // percentage
  startDate: string;
  endDate: string;
  bannerImage: string;
  applicableServices: number[]; // array of service IDs
}

export interface GalleryImage {
  id: number;
  title: string;
  url: string;
  category: string;
}

export interface Review {
  id: number;
  customerName: string;
  rating: number; // 1-5
  comment: string;
  avatar: string;
}

export type BookingStatus = 'Confirmed' | 'Pending' | 'Cancelled';

export interface Booking {
  id: number;
  customerName: string;
  serviceId: number;
  date: string; // Using string for mock data simplicity
  time: string;
  status: BookingStatus;
  notes?: string;
}

export interface BookingData {
  serviceId: number | null;
  date: Date | null;
  time: string | null;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  notes: string;
}
